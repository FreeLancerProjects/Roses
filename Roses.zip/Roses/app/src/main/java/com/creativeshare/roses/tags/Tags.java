package com.creativeshare.roses.tags;

public class Tags {

    public static final String base_url = "http://flower.agaaar.com/";
    public static final String IMAGE_URL = base_url+"upload/";
    public static final String IMAGE_URL2 = base_url+"storage/support/";

    public static final String session_login = "login";
    public static final String session_logout = "logout";





}
